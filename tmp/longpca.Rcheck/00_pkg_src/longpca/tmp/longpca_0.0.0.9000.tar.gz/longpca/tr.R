load("~/data_peeks/eth_explore/data/new_transactions.RData")
trans
im = make_interaction_model(~from_address*to_address, trans,duplicates = "none")
diagnose(im)
im$interaction_tibble

# Load necessary libraries
library(dplyr)
library(igraph)


im = add_graph_summaries(im)
im$row_universe$coreness |> summary()

core_threshold = 3
# im = im_original
im
diagnose(im)




