library(dplyr)
dat2 = data.table::fread("/Users/karlrohe/Downloads/dat2.txt")|> as_tibble()
dat3 = data.table::fread("/Users/karlrohe/Downloads/dat3.txt")|> as_tibble()
dat4 = data.table::fread("/Users/karlrohe/Downloads/dat4.txt")|> as_tibble()
dat5 = data.table::fread("/Users/karlrohe/Downloads/dat5.txt")|> as_tibble() |> mutate(Year = as.numeric(Year))
dat = bind_rows(dat2, dat3, dat4,dat5)
dat
dat |> colnames()

freeman_tukey <- function(x, n) {
  if (length(x) != length(n)) {
    stop("Vectors x and n must have the same length.")
  }

  ft_transform <- asin(sqrt(x / (n + 1))) + asin(sqrt((x + 1) / (n + 1)))

  return(ft_transform)
}

tib = dat |> select(urbanization = `2013 Urbanization`, age = `Ten-Year Age Groups`, icd = `ICD-10 113 Cause List`, year = Year, deaths = Deaths, population = Population, rate= `Crude Rate`)
# get rid of these:
tib |> filter(!grepl("[0-9]", population))
tib = tib |> filter(grepl("[0-9]", population)) |> mutate(pop = as.numeric(population))
tib  = tib |> mutate(rate_ft = 500*freeman_tukey(deaths, pop))

im = make_interaction_model(tib, rate_ft ~ (icd & age) * (urbanization & year))
diagnose(im)
# im$interaction_tibble
pcs = pca(im, 6)

streaks(pcs, "cols")
spcs = rotate(pcs= pcs, mode = "rows")
streaks(spcs)
streaks(spcs,"cols")
top(spcs, 3)

library(ggplot2)
spcs$column_features |>
  pivot_longer(-(urbanization:weighted_degree)) |>
  ggplot(aes(x = year, y = value))+geom_line()+facet_grid(name~urbanization, scales = "free_y")
# library(httr)
#
# # Example XML request body
# request_body <- '
# <request-parameters>
#     <accept_datause_restrictions>true</accept_datause_restrictions>
#     <parameter>
#         <name>B_1</name>
#         <value>D76.V1-level1</value> <!-- Example for Year -->
#     </parameter>
#     <parameter>
#         <name>B_2</name>
#         <value>D76.V9</value> <!-- Example for County, adjust as necessary -->
#     </parameter>
#     <parameter>
#         <name>B_3</name>
#         <value>D76.V10</value> <!-- Example for Age Group, adjust as necessary -->
#     </parameter>
#     <parameter>
#         <name>B_4</name>
#         <value>D76.V8</value> <!-- Example for Race -->
#     </parameter>
#     <parameter>
#         <name>F_D76.V2</name>
#         <value>[ICD-10 codes for types of death]</value> <!-- Replace with specific ICD-10 codes -->
#     </parameter>
#     <!-- Include additional parameters for measures and other specifics -->
#     <parameter>
#         <name>M_1</name>
#         <value>D76.M1</value> <!-- Number of deaths -->
#     </parameter>
#     <!-- Add other measures as needed -->
# </request-parameters>
# '
#
# response <- POST("https://wonder.cdc.gov/controller/datarequest/D76", body = request_body, encode = "raw")
#
# # Parsing the response
# parsed_response <- content(response, "text")
# print(parsed_response)
